[](https://www.zhihu.com/)

专栏[计算机（CS）保研](https://www.zhihu.com/column/c_1506013160984813568)

切换模式

计算机（CS）保研

末九CS，夏令营4%，预推免3%/1%保研经历

[![timeErrors](https://pic1.zhimg.com/v2-92fb28aef0ff383176f777056f2bcda5_l.jpg?source=d16d100b)](https://www.zhihu.com/people/guo-ke-82-96-72)

[timeErrors](https://www.zhihu.com/people/guo-ke-82-96-72)

·

28

篇内容

[下一页](https://www.zhihu.com/column/c_1506013160984813568?page=2)