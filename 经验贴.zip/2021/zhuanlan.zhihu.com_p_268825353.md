[](https://www.zhihu.com/)

*   [首页](https://www.zhihu.com/)
*   [知学堂](https://www.zhihu.com/education/learning)
*   [会员](https://www.zhihu.com/xen/vip-web)
*   [发现](https://www.zhihu.com/explore)
*   [等你来答](https://www.zhihu.com/question/waiting)

切换模式

5 秒后自动跳转至知乎首页

[去往首页](https://www.zhihu.com/)

![page error](https://static.zhihu.com/heifetz/assets/liukanshan_desert.ecf3c388.svg)