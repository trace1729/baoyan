计算机保研

关于计算机保研的经验、感悟的记录与分享，会持续更新

[![KID22](https://picx.zhimg.com/v2-be07a1a3ba92121f097fbd21a99629b8_l.jpg?source=d16d100b)](https://www.zhihu.com/people/kid-22-32-56)

[KID22](https://www.zhihu.com/people/kid-22-32-56)

·

3

篇内容